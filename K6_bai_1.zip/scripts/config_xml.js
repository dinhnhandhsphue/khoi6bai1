var TSC = TSC || {};

TSC.embedded_config_xml = '<x:xmpmeta tsc:version="2.0.1" xmlns:x="adobe:ns:meta/" xmlns:tsc="http://www.techsmith.com/xmp/tsc/">\
   <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#" xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:xmpDM="http://ns.adobe.com/xmp/1.0/DynamicMedia/" xmlns:xmpG="http://ns.adobe.com/xap/1.0/g/" xmlns:xmpMM="http://ns.adobe.com/xap/1.0/mm/" xmlns:tscDM="http://www.techsmith.com/xmp/tscDM/" xmlns:tscIQ="http://www.techsmith.com/xmp/tscIQ/" xmlns:tscHS="http://www.techsmith.com/xmp/tscHS/" xmlns:stDim="http://ns.adobe.com/xap/1.0/sType/Dimensions#" xmlns:stFnt="http://ns.adobe.com/xap/1.0/sType/Font#" xmlns:exif="http://ns.adobe.com/exif/1.0" xmlns:dc="http://purl.org/dc/elements/1.1/">\
      <rdf:Description dc:date="2023-06-19 10:05:26 AM" dc:source="Camtasia,9.1.0,enu" dc:title="K6_bai_1" tscDM:firstFrame="K6_bai_1_First_Frame.png" tscDM:originId="081C838D-F08C-460D-9E82-F7006C12B205" tscDM:project="Untitled Project">\
         <xmpDM:duration xmpDM:scale="1/1000" xmpDM:value="200500"/>\
         <xmpDM:videoFrameSize stDim:unit="pixel" stDim:h="1076" stDim:w="1920"/>\
         <tsc:langName>\
            <rdf:Bag>\
               <rdf:li xml:lang="en-US">English</rdf:li></rdf:Bag>\
         </tsc:langName>\
         <xmpDM:Tracks>\
            <rdf:Bag>\
               <rdf:li>\
                  <rdf:Description xmpDM:trackType="Quiz" xmpDM:frameRate="f1000" xmpDM:trackName="Quiz" tscIQ:quizGuid="A1E2CCF1-1964-4D79-B6CD-902DEB2C3AC4" tscIQ:authoredEmail="" tscIQ:requireUserId="0" tscIQ:locale="en-US" tscIQ:reportMethod="SCORM" tscIQ:allowSkipQuiz="0" tscIQ:clientId="1CDF22D874AC443FBBB68075B4AE31CD" tscIQ:hideReplay="0" tscIQ:quizHash="60d624cfe427363f0fffc7541e449c4f">\
                     <xmpDM:markers>\
                        <rdf:Seq>\
                           <rdf:li><rdf:Description xmpDM:startTime="58154" tscIQ:feedback="1" tscIQ:questionSetName="Quiz 1"><tscIQ:questions><rdf:Seq><rdf:li><rdf:Description tscIQ:type="MC" tscIQ:id="0"><tscIQ:question>Sổ báo bài  là vật mang tin</tscIQ:question><tscIQ:correctAnswer>1</tscIQ:correctAnswer><tscIQ:answerArray><rdf:Seq><rdf:li><rdf:Description tscIQ:orderId="0"><tscIQ:answer>True</tscIQ:answer></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:orderId="1"><tscIQ:answer>False</tscIQ:answer></rdf:Description></rdf:li></rdf:Seq></tscIQ:answerArray><tscIQ:feedback><rdf:Bag><rdf:li><rdf:Description tscIQ:reason="correct"><xmpDM:name><rdf:Alt><rdf:li>Chúc mừng bạn đã trả lời đúng!</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:reason="incorrect"><xmpDM:name><rdf:Alt><rdf:li>Bạn hãy cố gắng ở câu tiếp theo!</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li></rdf:Bag></tscIQ:feedback></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:type="MC" tscIQ:id="1"><tscIQ:question>Món ăn ngon là vật mang tin</tscIQ:question><tscIQ:correctAnswer>2</tscIQ:correctAnswer><tscIQ:answerArray><rdf:Seq><rdf:li><rdf:Description tscIQ:orderId="0"><tscIQ:answer>True</tscIQ:answer></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:orderId="1"><tscIQ:answer>False</tscIQ:answer></rdf:Description></rdf:li></rdf:Seq></tscIQ:answerArray><tscIQ:feedback><rdf:Bag><rdf:li><rdf:Description tscIQ:reason="correct"><xmpDM:name><rdf:Alt><rdf:li>Chúc mừng bạn đã trả lời đúng!</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:reason="incorrect"><xmpDM:name><rdf:Alt><rdf:li>Bạn hãy cố gắng ở câu tiếp theo!</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li></rdf:Bag></tscIQ:feedback></rdf:Description></rdf:li></rdf:Seq></tscIQ:questions></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:startTime="101115" tscIQ:feedback="1" tscIQ:questionSetName="Quiz 2"><tscIQ:questions><rdf:Seq><rdf:li><rdf:Description tscIQ:type="FITB" tscIQ:id="2"><tscIQ:question>Em hãy điền thêm vào chỗ chấm (…) trong câu để câu đó trở thành ví dụ minh họa phù hợp với  trường hợp  biết được thông tin trực tiếp từ quan sát sự vật, hiện tượng.: “Hùng...… nên biết rằng quả bóng đá của lớp vừa bị rách” . Chọn 1 trong 2 đáp án sau: 1. "đọc tin bạn nhắn" - 2. "nhìn quả bóng"</tscIQ:question><tscIQ:correctAnswer/><tscIQ:answerArray><rdf:Seq><rdf:li><rdf:Description tscIQ:orderId="0"><tscIQ:answer>nhìn quả bóng</tscIQ:answer></rdf:Description></rdf:li></rdf:Seq></tscIQ:answerArray><tscIQ:feedback><rdf:Bag><rdf:li><rdf:Description tscIQ:reason="correct"><xmpDM:name><rdf:Alt><rdf:li>Chúc mừng bạn đã trả lời đúng!</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:reason="incorrect"><xmpDM:name><rdf:Alt><rdf:li>Bạn hãy cố gắng ở câu tiếp theo!</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li></rdf:Bag></tscIQ:feedback></rdf:Description></rdf:li></rdf:Seq></tscIQ:questions></rdf:Description></rdf:li><rdf:li><rdf:Description xmpDM:startTime="125615" tscIQ:feedback="1" tscIQ:questionSetName="Quiz 4"><tscIQ:questions><rdf:Seq><rdf:li><rdf:Description tscIQ:type="MC" tscIQ:id="3"><tscIQ:question>Cho tình huống: ‘Em thấy quả cam có màu vàng, biết nó sắp chín”, em hãy chọn đáp án đúng nhất trong các câu sau:</tscIQ:question><tscIQ:correctAnswer>1</tscIQ:correctAnswer><tscIQ:answerArray><rdf:Seq><rdf:li><rdf:Description tscIQ:orderId="0"><tscIQ:answer>Quả cam có màu vàng là thông tin vào. Quả cam sắp chín là kết quả xử lý thông tin</tscIQ:answer></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:orderId="1"><tscIQ:answer>Quả cam có màu vàng là kết quả xử lý thông tin   </tscIQ:answer></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:orderId="2"><tscIQ:answer>Quả cam sắp chín là thông tin vào</tscIQ:answer></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:orderId="3"><tscIQ:answer>Quả cam có màu vàng, biết nó sắp chín là thông tin vào </tscIQ:answer></rdf:Description></rdf:li></rdf:Seq></tscIQ:answerArray><tscIQ:feedback><rdf:Bag><rdf:li><rdf:Description tscIQ:reason="correct"><xmpDM:name><rdf:Alt><rdf:li>Chúc mừng bạn đã trả lời đúng!</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li><rdf:li><rdf:Description tscIQ:reason="incorrect"><xmpDM:name><rdf:Alt><rdf:li>Bạn hãy cố gắng ở câu tiếp theo!</rdf:li></rdf:Alt></xmpDM:name></rdf:Description></rdf:li></rdf:Bag></tscIQ:feedback></rdf:Description></rdf:li></rdf:Seq></tscIQ:questions></rdf:Description></rdf:li></rdf:Seq>\
                     </xmpDM:markers>\
                     <tscIQ:QuizParams><rdf:Bag><rdf:li xmpDM:name="txtPrev" xmpDM:value="Previous"/><rdf:li xmpDM:name="txtNext" xmpDM:value="Next"/><rdf:li xmpDM:name="txtAnswerQuestion" xmpDM:value="Take Quiz Now"/><rdf:li xmpDM:name="txtSubmit" xmpDM:value="Submit Answers"/><rdf:li xmpDM:name="txtReview" xmpDM:value="Replay Last Section"/><rdf:li xmpDM:name="txtReviewAnswer" xmpDM:value="View Answers"/><rdf:li xmpDM:name="txtContinue" xmpDM:value="Continue"/></rdf:Bag></tscIQ:QuizParams></rdf:Description>\
               </rdf:li>\
            </rdf:Bag>\
         </xmpDM:Tracks>\
         <tscDM:controller>\
            <rdf:Description xmpDM:name="tscplayer">\
               <tscDM:parameters>\
                  <rdf:Bag>\
                     <rdf:li xmpDM:name="autohide" xmpDM:value="true"/><rdf:li xmpDM:name="autoplay" xmpDM:value="false"/><rdf:li xmpDM:name="loop" xmpDM:value="false"/><rdf:li xmpDM:name="searchable" xmpDM:value="false"/><rdf:li xmpDM:name="captionsenabled" xmpDM:value="false"/><rdf:li xmpDM:name="sidebarenabled" xmpDM:value="false"/><rdf:li xmpDM:name="unicodeenabled" xmpDM:value="false"/><rdf:li xmpDM:name="backgroundcolor" xmpDM:value="000000"/><rdf:li xmpDM:name="sidebarlocation" xmpDM:value="left"/><rdf:li xmpDM:name="endaction" xmpDM:value="stop"/><rdf:li xmpDM:name="endactionparam" xmpDM:value="true"/><rdf:li xmpDM:name="locale" xmpDM:value="en-US"/></rdf:Bag>\
               </tscDM:parameters>\
               <tscDM:controllerText>\
                  <rdf:Bag>\
                  </rdf:Bag>\
               </tscDM:controllerText>\
            </rdf:Description>\
         </tscDM:controller>\
         <tscDM:contentList>\
            <rdf:Description>\
               <tscDM:files>\
                  <rdf:Seq>\
                     <rdf:li xmpDM:name="0" xmpDM:value="K6_bai_1.mp4"/><rdf:li xmpDM:name="1" xmpDM:value="K6_bai_1.zip"/><rdf:li xmpDM:name="2" xmpDM:value="K6_bai_1_First_Frame.png"/></rdf:Seq>\
               </tscDM:files>\
            </rdf:Description>\
         </tscDM:contentList>\
      </rdf:Description>\
   </rdf:RDF>\
</x:xmpmeta>';
